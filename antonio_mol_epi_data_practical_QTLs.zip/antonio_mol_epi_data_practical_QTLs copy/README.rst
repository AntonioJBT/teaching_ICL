Teaching at ICL
################

Repository for the data analysis practicals (QTL) for the molecular and genetic epidemiology module.
See the html files in code/ for the exercises.

To render the html files e.g. week_2_analysis_practical_1.html go to:

https://htmlpreview.github.io/?https://github.com/AntonioJBT/teaching_ICL/blob/master/code/week_2_analysis_practical_1.html

Download data for practical 2b from:

https://tinyurl.com/tu25pwj

To simulate large files see the README in data/


